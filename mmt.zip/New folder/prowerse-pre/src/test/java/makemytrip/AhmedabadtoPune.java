package makemytrip;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

public class AhmedabadtoPune {
	
	
	@Test
	public void setUp() throws InterruptedException{
		
		WebDriver driver = new ChromeDriver ();
		
		 driver.get("https://www.makemytrip.com/flights/");
		 Thread.sleep(5000);
		 driver.manage().window().maximize();
		 
		 driver.findElement(By.xpath("(//span[@class='commonModal__close'])[1]")).click();
	
		 
		
		// Select From city - Ahmedabad
	        driver.findElement(By.xpath("(//label[@for='fromCity'])[1]")).click();
	        driver.findElement(By.xpath("(//input[@placeholder='From'])[1]")).click();
	        driver.findElement(By.xpath("(//input[@placeholder='From'])[1]")).sendKeys("Ahmedabad");
	        Thread.sleep(5000);
	        driver.findElement(By.xpath("(//span[contains(text(),'Ahmedabad')])[1]")).click();
	        
	        
	     // Select To city - Pune
	        driver.findElement(By.xpath("(//input[@id='toCity'])[1]")).click();
	        driver.findElement(By.xpath("(//input[@placeholder='To'])[1]")).click();
	        driver.findElement(By.xpath("(//input[@placeholder='To'])[1]")).sendKeys("Pune");
	        Thread.sleep(5000);
	        driver.findElement(By.xpath("(//span[contains(text(),'Pune')])[1]")).click();
	        
	     // Select departure date (1st of next month)
	        driver.findElement(By.xpath("(//div[contains(@class,'dateInnerCell')])[32]")).click();
	        Thread.sleep(5000);
	        
	        // Select passengers (2 adults, 1 child, 1 infant)
	        driver.findElement(By.xpath("(//label[@for='travellers'])[1]")).click();
	        driver.findElement(By.xpath("//body/div[@id='root']/div[@id='top-banner']/div[@class='minContainer']/div/div[@class='flightWidgetSection appendBottom40']/div[@class='searchWidgetContainer']/div[@class='fltWidgetSection fltWidgetSection appendBottom40 primaryTraveler ']/div[@class='fsw widgetOpen']/div[@class='fsw_inner returnPersuasion']/div[@class='flt_fsw_inputBox flightTravllers inactiveWidget activeWidget']/div[@class='fltTravellers gbTravellers']/div[@class='appendBottom20']/ul[@class='guestCounter font12 darkText gbCounter']/li[2]")).click();
	        driver.findElement(By.xpath("//div[@class='makeFlex column childCounter']//li[2]")).click();
	        driver.findElement(By.xpath("//div[@class='makeFlex column pushRight infantCounter']//li[2]")).click();
	        driver.findElement(By.xpath("//button[normalize-space()='APPLY']")).click();
	        
	     // Click on the search button
	        driver.findElement(By.xpath("(//a[normalize-space()='Search'])[1]")).click();
	
	
	 
			// Verify trip details
	       String tripType = driver.findElement(By.xpath("//div[@class='multiDropDownVal']")).getText();
	       System.out.println(tripType);
	       driver.findElement(By.xpath("(//input[@id='fromCity'])[1]")).click();
	       String fromCityVerify = driver.findElement(By.xpath("(//p[normalize-space()='Ahmedabad, India'])[1]")).getText();
	       System.out.println(fromCityVerify);
	       driver.findElement(By.xpath("(//input[@id='toCity'])[1]")).click();
	       String toCityVerify = driver.findElement(By.xpath("(//p[normalize-space()='Pune, India'])[1]")).getText();
	       System.out.println(toCityVerify);
	       driver.findElement(By.xpath("(//input[@id='departure'])[1]")).click();
	       String departVerify = driver.findElement(By.xpath("//div[@aria-label='Thursday, 1 August 2024']//div[@class='dateContainer']")).getText();
	        System.out.println(departVerify);
	    	WebElement passengersVerify = driver.findElement(By.xpath("(//input[@id='travellerAndClass'])[1]"));
	        
	       
            Assert.assertTrue(tripType.contains("One Way"));
	        Assert.assertTrue(fromCityVerify.contains("Ahmedabad"));
	   Assert.assertTrue(toCityVerify.contains("Pune"));
	      Assert.assertTrue(departVerify.contains("1 August 2024"));
         
	        
	        
	       
	        
	        
	       driver.quit();
	        
	  
	       

	       

	}
}	
